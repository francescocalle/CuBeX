#ifndef stepCuBeX
#define stepCuBeX
#include <Arduino.h>
#include <Wire.h>

void stepper_UD(int adr1);                                   //funzioni da richiamare per inizializzarei motori stepper
void stepper_RL(int adr2);
void stepper_FB(int adr3);
void stepper_RPM(int speed);                                   //funzione per impostare la velocità dei motori
void stepper_LUN(int lunghezzamossa);                          //funzione per impostare gli step da fare per mossa (se negativa il motore gira in senso antiorario)
void step_U();                                                 //funzione per richiamare una determinata  mossa
void step_D();
void step_R();
void step_L();
void step_F();
void step_B();
void step_CUS();                                               //funzione per richiamare una mossa custom che muove U e D nel senso opposto

void movu();                                                   //funzioni aggiuntive
void movd();
void movr();
void movl();
void movf();
void movb();
void aggexp();

#endif