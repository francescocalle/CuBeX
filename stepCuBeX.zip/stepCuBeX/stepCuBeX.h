#ifndef stepCuBeX
#define stepCuBeX
#include <Arduino.h>

void stepper_U(int Upin1,int Upin2,int Upin3,int Upin4);       //funzioni da richiamare per inizializzarei motori stepper e i loro pin
void stepper_D(int Dpin1,int Dpin2,int Dpin3,int Dpin4);
void stepper_R(int Rpin1,int Rpin2,int Rpin3,int Rpin4);
void stepper_L(int Lpin1,int Lpin2,int Lpin3,int Lpin4);
void stepper_F(int Fpin1,int Fpin2,int Fpin3,int Fpin4);
void stepper_B(int Bpin1,int Bpin2,int Bpin3,int Bpin4);
void stepper_RPM(int speed);                                   //funzione per impostare la velocità dei motori
void stepper_LUN(int lunghezzamossa);                          //funzione per impostare gli step da fare per mossa (se negativa il motore gira in senso antiorario)
void step_U();                                                 //funzione per richiamare una determinata  mossa
void step_D();
void step_R();
void step_L();
void step_F();
void step_B();
void step_CUS();                                               //funzione per richiamare una mossa custom che muove U e D nel senso opposto

void movu();                                                   //funzioni aggiuntive
void movd();
void movr();
void movl();
void movf();
void movb();

#endif