#include <stepCuBeX.h>
unsigned long t_init;
float tempostep = 5000;
int cicli1, SU=0, SD=0, SR=0, SL=0, SF=0, SB=0, lunghe=50, dir404=1;
int Uspin1 = 0, Uspin2 = 0, Uspin3 = 0, Uspin4 = 0;
int Dspin1 = 0, Dspin2 = 0, Dspin3 = 0, Dspin4 = 0;
int Rspin1 = 0, Rspin2 = 0, Rspin3 = 0, Rspin4 = 0;
int Lspin1 = 0, Lspin2 = 0, Lspin3 = 0, Lspin4 = 0;
int Fspin1 = 0, Fspin2 = 0, Fspin3 = 0, Fspin4 = 0;
int Bspin1 = 0, Bspin2 = 0, Bspin3 = 0, Bspin4 = 0;

void stepper_U(int Upin1,int Upin2,int Upin3,int Upin4){    //funzioni da richiamare per inizializzarei motori stepper e i loro pin
  Uspin1=Upin1;
  Uspin2=Upin2;
  Uspin3=Upin3;
  Uspin4=Upin4;
  pinMode(Uspin1, OUTPUT);
  pinMode(Uspin2, OUTPUT);
  pinMode(Uspin3, OUTPUT);
  pinMode(Uspin4, OUTPUT);
}
void stepper_D(int Dpin1,int Dpin2,int Dpin3,int Dpin4){
  Dspin1=Dpin1;
  Dspin2=Dpin2;
  Dspin3=Dpin3;
  Dspin4=Dpin4;
  pinMode(Dspin1, OUTPUT);
  pinMode(Dspin2, OUTPUT);
  pinMode(Dspin3, OUTPUT);
  pinMode(Dspin4, OUTPUT);
}
void stepper_R(int Rpin1,int Rpin2,int Rpin3,int Rpin4){
  Rspin1=Rpin1;
  Rspin2=Rpin2;
  Rspin3=Rpin3;
  Rspin4=Rpin4;
  pinMode(Rspin1, OUTPUT);
  pinMode(Rspin2, OUTPUT);
  pinMode(Rspin3, OUTPUT);
  pinMode(Rspin4, OUTPUT);
}
void stepper_L(int Lpin1,int Lpin2,int Lpin3,int Lpin4){
  Lspin1=Lpin1;
  Lspin2=Lpin2;
  Lspin3=Lpin3;
  Lspin4=Lpin4;
  pinMode(Lspin1, OUTPUT);
  pinMode(Lspin2, OUTPUT);
  pinMode(Lspin3, OUTPUT);
  pinMode(Lspin4, OUTPUT);
}
void stepper_F(int Fpin1,int Fpin2,int Fpin3,int Fpin4){
  Fspin1=Fpin1;
  Fspin2=Fpin2;
  Fspin3=Fpin3;
  Fspin4=Fpin4;
  pinMode(Fspin1, OUTPUT);
  pinMode(Fspin2, OUTPUT);
  pinMode(Fspin3, OUTPUT);
  pinMode(Fspin4, OUTPUT);
}
void stepper_B(int Bpin1,int Bpin2,int Bpin3,int Bpin4){
  Bspin1=Bpin1;
  Bspin2=Bpin2;
  Bspin3=Bpin3;
  Bspin4=Bpin4;
  pinMode(Bspin1, OUTPUT);
  pinMode(Bspin2, OUTPUT);
  pinMode(Bspin3, OUTPUT);
  pinMode(Bspin4, OUTPUT);
}
void stepper_RPM(int speed){                            //funzione per impostare la velocità dei motori
  tempostep = 300000 / speed;
}
void stepper_LUN(int lunghezzamossa){                   //funzione per impostare gli step da fare per mossa
  lunghe = lunghezzamossa;
  if(lunghe > 0){
    dir404=1;
  }else if(lunghe < 0){
    dir404=0;
  }else{
    dir404=2;
  }

}
void step_U(){                                                 //funzione per richiamare una determinata  mossa
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SU++;
      if(SU > 3){
        SU=0;
      }
      movu();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Uspin1, LOW);
    digitalWrite(Uspin2, LOW);
    digitalWrite(Uspin3, LOW);
    digitalWrite(Uspin4, LOW);
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SU--;
      if(SU < 0){
        SU=3;
      }
      movu();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Uspin1, LOW);
    digitalWrite(Uspin2, LOW);
    digitalWrite(Uspin3, LOW);
    digitalWrite(Uspin4, LOW);
  }
}
void step_D(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SD++;
      if(SD > 3){
        SD=0;
      }
      movd();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Dspin1, LOW);
    digitalWrite(Dspin2, LOW);
    digitalWrite(Dspin3, LOW);
    digitalWrite(Dspin4, LOW);
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SD--;
      if(SD < 0){
        SD=3;
      }
      movd();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Dspin1, LOW);
    digitalWrite(Dspin2, LOW);
    digitalWrite(Dspin3, LOW);
    digitalWrite(Dspin4, LOW);
  }
}
void step_R(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SR++;
      if(SR > 3){
        SR=0;
      }
      movr();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Rspin1, LOW);
    digitalWrite(Rspin2, LOW);
    digitalWrite(Rspin3, LOW);
    digitalWrite(Rspin4, LOW);
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SR--;
      if(SR < 0){
        SR=3;
      }
      movr();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Rspin1, LOW);
    digitalWrite(Rspin2, LOW);
    digitalWrite(Rspin3, LOW);
    digitalWrite(Rspin4, LOW);
  }
}
void step_L(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SL++;
      if(SL > 3){
        SL=0;
      }
      movl();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Lspin1, LOW);
    digitalWrite(Lspin2, LOW);
    digitalWrite(Lspin3, LOW);
    digitalWrite(Lspin4, LOW);
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SL--;
      if(SL < 0){
        SL=3;
      }
      movl();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Lspin1, LOW);
    digitalWrite(Lspin2, LOW);
    digitalWrite(Lspin3, LOW);
    digitalWrite(Lspin4, LOW);
  }
}
void step_F(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SF++;
      if(SF > 3){
        SF=0;
      }
      movf();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Fspin1, LOW);
    digitalWrite(Fspin2, LOW);
    digitalWrite(Fspin3, LOW);
    digitalWrite(Fspin4, LOW);
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SF--;
      if(SF < 0){
        SF=3;
      }
      movf();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Fspin1, LOW);
    digitalWrite(Fspin2, LOW);
    digitalWrite(Fspin3, LOW);
    digitalWrite(Fspin4, LOW);
  }
}
void step_B(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SB++;
      if(SB > 3){
        SB=0;
      }
      movb();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Bspin1, LOW);
    digitalWrite(Bspin2, LOW);
    digitalWrite(Bspin3, LOW);
    digitalWrite(Bspin4, LOW);
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SB--;
      if(SB < 0){
        SB=3;
      }
      movb();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Bspin1, LOW);
    digitalWrite(Bspin2, LOW);
    digitalWrite(Bspin3, LOW);
    digitalWrite(Bspin4, LOW);
  }
}
void step_CUS(){                                               //funzione per richiamare una mossa custom che muove U e D nel senso opposto
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SU++;
      if(SU > 3){
        SU=0;
      }
      SD--;
      if(SD < 0){
        SD=3;
      }
      movu();
      movd();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Uspin1, LOW);
    digitalWrite(Uspin2, LOW);
    digitalWrite(Uspin3, LOW);
    digitalWrite(Uspin4, LOW);
    digitalWrite(Dspin1, LOW);
    digitalWrite(Dspin2, LOW);
    digitalWrite(Dspin3, LOW);
    digitalWrite(Dspin4, LOW);
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SU--;
      if(SU < 0){
        SU=3;
      }
      SD++;
      if(SD > 3){
        SD=0;
      }
      movu();
      movd();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
    digitalWrite(Uspin1, LOW);
    digitalWrite(Uspin2, LOW);
    digitalWrite(Uspin3, LOW);
    digitalWrite(Uspin4, LOW);
    digitalWrite(Dspin1, LOW);
    digitalWrite(Dspin2, LOW);
    digitalWrite(Dspin3, LOW);
    digitalWrite(Dspin4, LOW);
  }
}
void movu(){
  if(SU==0){
    digitalWrite(Uspin1, HIGH);
    digitalWrite(Uspin2, LOW);
    digitalWrite(Uspin3, HIGH);
    digitalWrite(Uspin4, LOW);
  }
  if(SU==1){
    digitalWrite(Uspin1, LOW);
    digitalWrite(Uspin2, HIGH);
    digitalWrite(Uspin3, HIGH);
    digitalWrite(Uspin4, LOW);
  }
  if(SU==2){
    digitalWrite(Uspin1, LOW);
    digitalWrite(Uspin2, HIGH);
    digitalWrite(Uspin3, LOW);
    digitalWrite(Uspin4, HIGH);
  }
  if(SU==3){
    digitalWrite(Uspin1, HIGH);
    digitalWrite(Uspin2, LOW);
    digitalWrite(Uspin3, LOW);
    digitalWrite(Uspin4, HIGH);
  }
}
void movd(){
  if(SD==0){
    digitalWrite(Dspin1, HIGH);
    digitalWrite(Dspin2, LOW);
    digitalWrite(Dspin3, HIGH);
    digitalWrite(Dspin4, LOW);
  }
  if(SD==1){
    digitalWrite(Dspin1, LOW);
    digitalWrite(Dspin2, HIGH);
    digitalWrite(Dspin3, HIGH);
    digitalWrite(Dspin4, LOW);
  }
  if(SD==2){
    digitalWrite(Dspin1, LOW);
    digitalWrite(Dspin2, HIGH);
    digitalWrite(Dspin3, LOW);
    digitalWrite(Dspin4, HIGH);
  }
  if(SD==3){
    digitalWrite(Dspin1, HIGH);
    digitalWrite(Dspin2, LOW);
    digitalWrite(Dspin3, LOW);
    digitalWrite(Dspin4, HIGH);
  }
}
void movr(){
  if(SR==0){
    digitalWrite(Rspin1, HIGH);
    digitalWrite(Rspin2, LOW);
    digitalWrite(Rspin3, HIGH);
    digitalWrite(Rspin4, LOW);
  }
  if(SR==1){
    digitalWrite(Rspin1, LOW);
    digitalWrite(Rspin2, HIGH);
    digitalWrite(Rspin3, HIGH);
    digitalWrite(Rspin4, LOW);
  }
  if(SR==2){
    digitalWrite(Rspin1, LOW);
    digitalWrite(Rspin2, HIGH);
    digitalWrite(Rspin3, LOW);
    digitalWrite(Rspin4, HIGH);
  }
  if(SR==3){
    digitalWrite(Rspin1, HIGH);
    digitalWrite(Rspin2, LOW);
    digitalWrite(Rspin3, LOW);
    digitalWrite(Rspin4, HIGH);
  }
}
void movl(){
  if(SL==0){
    digitalWrite(Lspin1, HIGH);
    digitalWrite(Lspin2, LOW);
    digitalWrite(Lspin3, HIGH);
    digitalWrite(Lspin4, LOW);
  }
  if(SL==1){
    digitalWrite(Lspin1, LOW);
    digitalWrite(Lspin2, HIGH);
    digitalWrite(Lspin3, HIGH);
    digitalWrite(Lspin4, LOW);
  }
  if(SL==2){
    digitalWrite(Lspin1, LOW);
    digitalWrite(Lspin2, HIGH);
    digitalWrite(Lspin3, LOW);
    digitalWrite(Lspin4, HIGH);
  }
  if(SL==3){
    digitalWrite(Lspin1, HIGH);
    digitalWrite(Lspin2, LOW);
    digitalWrite(Lspin3, LOW);
    digitalWrite(Lspin4, HIGH);
  }
}
void movf(){
  if(SF==0){
    digitalWrite(Fspin1, HIGH);
    digitalWrite(Fspin2, LOW);
    digitalWrite(Fspin3, HIGH);
    digitalWrite(Fspin4, LOW);
  }
  if(SF==1){
    digitalWrite(Fspin1, LOW);
    digitalWrite(Fspin2, HIGH);
    digitalWrite(Fspin3, HIGH);
    digitalWrite(Fspin4, LOW);
  }
  if(SF==2){
    digitalWrite(Fspin1, LOW);
    digitalWrite(Fspin2, HIGH);
    digitalWrite(Fspin3, LOW);
    digitalWrite(Fspin4, HIGH);
  }
  if(SF==3){
    digitalWrite(Fspin1, HIGH);
    digitalWrite(Fspin2, LOW);
    digitalWrite(Fspin3, LOW);
    digitalWrite(Fspin4, HIGH);
  }
}
void movb(){
  if(SB==0){
    digitalWrite(Bspin1, HIGH);
    digitalWrite(Bspin2, LOW);
    digitalWrite(Bspin3, HIGH);
    digitalWrite(Bspin4, LOW);
  }
  if(SB==1){
    digitalWrite(Bspin1, LOW);
    digitalWrite(Bspin2, HIGH);
    digitalWrite(Bspin3, HIGH);
    digitalWrite(Bspin4, LOW);
  }
  if(SB==2){
    digitalWrite(Bspin1, LOW);
    digitalWrite(Bspin2, HIGH);
    digitalWrite(Bspin3, LOW);
    digitalWrite(Bspin4, HIGH);
  }
  if(SB==3){
    digitalWrite(Bspin1, HIGH);
    digitalWrite(Bspin2, LOW);
    digitalWrite(Bspin3, LOW);
    digitalWrite(Bspin4, HIGH);
  }
}