#include <stepCuBeX.h>
unsigned long t_init;
float tempostep = 5000;
int cicli1, SU=0, SD=0, SR=0, SL=0, SF=0, SB=0, lunghe=50, dir404=1;
int Upin1 = 1, Upin2 = 1, Upin3 = 1, Upin4 = 1;
int Dpin1 = 1, Dpin2 = 1, Dpin3 = 1, Dpin4 = 1;
int Rpin1 = 1, Rpin2 = 1, Rpin3 = 1, Rpin4 = 1;
int Lpin1 = 1, Lpin2 = 1, Lpin3 = 1, Lpin4 = 1;
int Fpin1 = 1, Fpin2 = 1, Fpin3 = 1, Fpin4 = 1;
int Bpin1 = 1, Bpin2 = 1, Bpin3 = 1, Bpin4 = 1;
int exp1, exp2, exp3;
int adrs1 = "0x00";
int adrs2 = "0x00";
int adrs3 = "0x00";

void stepper_UD(int adr1){    //funzioni da richiamare per inizializzarei motori stepper e i loro pin
  adrs1 = adr1,
  Wire.begin();
  Wire.beginTransmission(adrs1);
  Wire.write((byte)0b11111111);
  Wire.endTransmission();
}
void stepper_RL(int adr2){
  adrs2 = adr2,
  Wire.begin();
  Wire.beginTransmission(adrs2);
  Wire.write((byte)0b11111111);
  Wire.endTransmission();
}
void stepper_FB(int adr3){
  adrs3 = adr3,
  Wire.begin();
  Wire.beginTransmission(adrs3);
  Wire.write((byte)0b11111111);
  Wire.endTransmission();

}
void stepper_RPM(int speed){                            //funzione per impostare la velocità dei motori
  tempostep = 300000 / speed;
}
void stepper_LUN(int lunghezzamossa){                   //funzione per impostare gli step da fare per mossa
  lunghe = lunghezzamossa;
  if(lunghe > 0){
    dir404=1;
  }else if(lunghe < 0){
    dir404=0;
  }else{
    dir404=2;
  }

}
void step_U(){                                                 //funzione per richiamare una determinata  mossa
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SU++;
      if(SU > 3){
        SU=0;
      }
      movu();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SU--;
      if(SU < 0){
        SU=3;
      }
      movu();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Upin1 = 1;
  Upin2 = 1;
  Upin3 = 1;
  Upin4 = 1;
  aggexp();
}
void step_D(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SD++;
      if(SD > 3){
        SD=0;
      }
      movd();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SD--;
      if(SD < 0){
        SD=3;
      }
      movd();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Dpin1 = 1;
  Dpin2 = 1;
  Dpin3 = 1;
  Dpin4 = 1;
  aggexp();
}
void step_R(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SR++;
      if(SR > 3){
        SR=0;
      }
      movr();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SR--;
      if(SR < 0){
        SR=3;
      }
      movr();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Rpin1 = 1;
  Rpin2 = 1;
  Rpin3 = 1;
  Rpin4 = 1;
  aggexp();
}
void step_L(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SL++;
      if(SL > 3){
        SL=0;
      }
      movl();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SL--;
      if(SL < 0){
        SL=3;
      }
      movl();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Lpin1 = 1;
  Lpin2 = 1;
  Lpin3 = 1;
  Lpin4 = 1;
  aggexp();
}
void step_F(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SF++;
      if(SF > 3){
        SF=0;
      }
      movf();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SF--;
      if(SF < 0){
        SF=3;
      }
      movf();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Fpin1 = 1;
  Fpin2 = 1;
  Fpin3 = 1;
  Fpin4 = 1;
  aggexp();
}
void step_B(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SB++;
      if(SB > 3){
        SB=0;
      }
      movb();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SB--;
      if(SB < 0){
        SB=3;
      }
      movb();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Bpin1 = 1;
  Bpin2 = 1;
  Bpin3 = 1;
  Bpin4 = 1;
  aggexp();
}
void step_CUS(){                                               //funzione per richiamare una mossa custom che muove U e D nel senso opposto
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SU++;
      if(SU > 3){
        SU=0;
      }
      SD--;
      if(SD < 0){
        SD=3;
      }
      movu();
      movd();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SU--;
      if(SU < 0){
        SU=3;
      }
      SD++;
      if(SD > 3){
        SD=0;
      }
      movu();
      movd();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Upin1 = 1;
  Upin2 = 1;
  Upin3 = 1;
  Upin4 = 1;
  Dpin1 = 1;
  Dpin2 = 1;
  Dpin3 = 1;
  Dpin4 = 1;
  aggexp();
}
void movu(){
  if(SU==0){
    Upin1 = 0;
    Upin2 = 1;
    Upin3 = 0;
    Upin4 = 1;
  }
  if(SU==1){
    Upin1 = 1;
    Upin2 = 0;
    Upin3 = 0;
    Upin4 = 1;
  }
  if(SU==2){
    Upin1 = 1;
    Upin2 = 0;
    Upin3 = 1;
    Upin4 = 0;
  }
  if(SU==3){
    Upin1 = 0;
    Upin2 = 1;
    Upin3 = 1;
    Upin4 = 0;
  }
}
void movd(){
  if(SD==0){
    Dpin1 = 0;
    Dpin2 = 1;
    Dpin3 = 0;
    Dpin4 = 1;
  }
  if(SD==1){
    Dpin1 = 1;
    Dpin2 = 0;
    Dpin3 = 0;
    Dpin4 = 1;
  }
  if(SD==2){
    Dpin1 = 1;
    Dpin2 = 0;
    Dpin3 = 1;
    Dpin4 = 0;
  }
  if(SD==3){
    Dpin1 = 0;
    Dpin2 = 1;
    Dpin3 = 1;
    Dpin4 = 0;
  }
}
void movr(){
  if(SR==0){
    Rpin1 = 0;
    Rpin2 = 1;
    Rpin3 = 0;
    Rpin4 = 1;
  }
  if(SR==1){
    Rpin1 = 1;
    Rpin2 = 0;
    Rpin3 = 0;
    Rpin4 = 1;
  }
  if(SR==2){
    Rpin1 = 1;
    Rpin2 = 0;
    Rpin3 = 1;
    Rpin4 = 0;
  }
  if(SR==3){
    Rpin1 = 0;
    Rpin2 = 1;
    Rpin3 = 1;
    Rpin4 = 0;
  }
}
void movl(){
  if(SL==0){
    Lpin1 = 0;
    Lpin2 = 1;
    Lpin3 = 0;
    Lpin4 = 1;
  }
  if(SL==1){
    Lpin1 = 1;
    Lpin2 = 0;
    Lpin3 = 0;
    Lpin4 = 1;
  }
  if(SL==2){
    Lpin1 = 1;
    Lpin2 = 0;
    Lpin3 = 1;
    Lpin4 = 0;
  }
  if(SL==3){
    Lpin1 = 0;
    Lpin2 = 1;
    Lpin3 = 1;
    Lpin4 = 0;
  }
}
void movf(){
  if(SF==0){
    Fpin1 = 0;
    Fpin2 = 1;
    Fpin3 = 0;
    Fpin4 = 1;
  }
  if(SF==1){
    Fpin1 = 1;
    Fpin2 = 0;
    Fpin3 = 0;
    Fpin4 = 1;
  }
  if(SF==2){
    Fpin1 = 1;
    Fpin2 = 0;
    Fpin3 = 1;
    Fpin4 = 0;
  }
  if(SF==3){
    Fpin1 = 0;
    Fpin2 = 1;
    Fpin3 = 1;
    Fpin4 = 0;
  }
}
void movb(){
  if(SB==0){
    Bpin1 = 0;
    Bpin2 = 1;
    Bpin3 = 0;
    Bpin4 = 1;
  }
  if(SB==1){
    Bpin1 = 1;
    Bpin2 = 0;
    Bpin3 = 0;
    Bpin4 = 1;
  }
  if(SB==2){
    Bpin1 = 1;
    Bpin2 = 0;
    Bpin3 = 1;
    Bpin4 = 0;
  }
  if(SB==3){
    Bpin1 = 0;
    Bpin2 = 1;
    Bpin3 = 1;
    Bpin4 = 0;
  }
}
void aggexp(){
  exp1 = (Dpin4*128) + (Dpin3*64) + (Dpin2*32) + (Dpin1*16) + (Upin4*8) + (Upin3*4) + (Upin2*2) + Upin1;
  Wire.beginTransmission(adrs1);
  Wire.write(exp1);
  Wire.endTransmission();
  exp2 = (Lpin4*128) + (Lpin3*64) + (Lpin2*32) + (Lpin1*16) + (Rpin4*8) + (Rpin3*4) + (Rpin2*2) + Rpin1;
  Wire.beginTransmission(adrs2);
  Wire.write(exp2);
  Wire.endTransmission();
  exp3 = (Bpin4*128) + (Bpin3*64) + (Bpin2*32) + (Bpin1*16) + (Fpin4*8) + (Fpin3*4) + (Fpin2*2) + Fpin1;
  Wire.beginTransmission(adrs3);
  Wire.write(exp3);
  Wire.endTransmission();
}