#include <servoCuBeX.h>
const int pwmmin = 1638;
const int pwmmax = 8190;
int ss1a, ss2a, ss3a, ss4a, ss1c, ss2c, ss3c, ss4c, pinss1, pinss2, pinss3, pinss4;
void servo_1(int pins1, int s1c, int s1a){ //funzioni per creare i servomotori servo*(pin, angolo da chiuso, angolo da aperto);
  ledcAttach(pins1, 50, 16);
  pinss1 = pins1;
  ss1a = map(s1a,0,180,pwmmin,pwmmax);
  ss1c = map(s1c,0,180,pwmmin,pwmmax);
}
void servo_2(int pins2, int s2c, int s2a){
  ledcAttach(pins2, 50, 16);
  pinss2 = pins2;
  ss2a = map(s2a,0,180,pwmmin,pwmmax);
  ss2c = map(s2c,0,180,pwmmin,pwmmax);
}
void servo_3(int pins3, int s3c, int s3a){
  ledcAttach(pins3, 50, 16);
  pinss3 = pins3;
  ss3a = map(s3a,0,180,pwmmin,pwmmax);
  ss3c = map(s3c,0,180,pwmmin,pwmmax);
}
void servo_4(int pins4, int s4c, int s4a){
  ledcAttach(pins4,50, 16);
  pinss4 = pins4;
  ss4a = map(s4a,0,180,pwmmin,pwmmax);
  ss4c = map(s4c,0,180,pwmmin,pwmmax);
}
void servo_op(){                           //funzione per aprire i servo
  ledcWrite(pinss1,ss1a);
  ledcWrite(pinss2,ss2a);
  ledcWrite(pinss3,ss3a);
  ledcWrite(pinss4,ss4a);
}
void servo_cl(){                           //funzione per chiudere i servo
  ledcWrite(pinss1,ss1c);
  ledcWrite(pinss2,ss2c);
  ledcWrite(pinss3,ss3c);
  ledcWrite(pinss4,ss4c);
}