#ifndef servoCuBeX
#define servoCuBeX
#include <Arduino.h>

void servo_1(int pins1, int s1c, int s1a); //funzioni per creare i servomotori servo*(pin, angolo da chiuso, angolo da aperto);
void servo_2(int pins2, int s2c, int s2a);
void servo_3(int pins3, int s3c, int s3a);
void servo_4(int pins4, int s4c, int s4a);
void servo_op();                           //funzione per aprire i servo
void servo_cl();                           //funzione per chiudere i servo

#endif