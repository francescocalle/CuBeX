// ============================================================================
//  Codici errore (errori()):
//   0 nessun errore            1 colori non validi (ogni colore deve comparire 9 volte)
//   2 spigolo non valido       3 angolo non valido
//   4 spigolo girato singolo   5 angolo ruotato singolo
//   6 scambio singolo (parita) 7 memoria insufficiente
//   8 errore interno (non dovrebbe mai succedere)
// ============================================================================
#include<CuBeX_3.0.h>
#if defined(ARDUINO_ARCH_ESP32) || defined(ESP_PLATFORM)
#include <esp_heap_caps.h>
#define CUBEX_ESP32 1
#endif
#define CUBEX_TEMPO_MAX_MS            20000UL
#define CUBEX_TEMPO_MIGLIORAMENTO_MS  10000UL

const int w  = 1;  //assegno un numero ai colori
const int y  = 2;
const int g  = 3;
const int b  = 4;
const int r  = 5;
const int o  = 6;

int CFW[9] = { 0, 0, 0, 0, 1, 0, 0, 0, 0 };
int CFY[9] = { 0, 0, 0, 0, 2, 0, 0, 0, 0 };
int CFG[9] = { 0, 0, 0, 0, 3, 0, 0, 0, 0 };
int CFB[9] = { 0, 0, 0, 0, 4, 0, 0, 0, 0 };
int CFR[9] = { 0, 0, 0, 0, 5, 0, 0, 0, 0 };
int CFO[9] = { 0, 0, 0, 0, 6, 0, 0, 0, 0 };
int alg[255];  //questo vettore serve per tenere a mente le mosse da fare per la risoluzione
int temp_init = 0, numero404notfound = 0, er404notfound = 0;

//variabili per gli stepper
unsigned long t_init;
float tempostep = 5000;
int cicli1, SU=0, SD=0, SR=0, SL=0, SF=0, SB=0, lunghe=50, dir404=1;
int Upin1 = 1, Upin2 = 1, Upin3 = 1, Upin4 = 1;
int Dpin1 = 1, Dpin2 = 1, Dpin3 = 1, Dpin4 = 1;
int Rpin1 = 1, Rpin2 = 1, Rpin3 = 1, Rpin4 = 1;
int Lpin1 = 1, Lpin2 = 1, Lpin3 = 1, Lpin4 = 1;
int Fpin1 = 1, Fpin2 = 1, Fpin3 = 1, Fpin4 = 1;
int Bpin1 = 1, Bpin2 = 1, Bpin3 = 1, Bpin4 = 1;
int exp1, exr2, exp3;
int adrs1 = 0;
int adrs2 = 0;
int adrs3 = 0;

//variabili per i  servo
const int pwmmin = 1638;
const int pwmmax = 8190;
int ss1a, ss2a, ss3a, ss4a, ss1c, ss2c, ss3c, ss4c, pinss1, pinss2, pinss3, pinss4;


//aggiorna le facce
void af_W(int CFW1,int CFW2,int CFW3,int CFW4,int CFW5,int CFW6,int CFW7,int CFW8){  //quì vanno inseriti i colori delle varie facce (no i centri)
  CFW[0] =CFW1;
  CFW[1] =CFW2;
  CFW[2] =CFW3;
  CFW[3] =CFW4;
  CFW[5] =CFW5;
  CFW[6] =CFW6;
  CFW[7] =CFW7;
  CFW[8] =CFW8;
}
void af_Y(int CFY1,int CFY2,int CFY3,int CFY4,int CFY5,int CFY6,int CFY7,int CFY8){
  CFY[0] =CFY1;
  CFY[1] =CFY2;
  CFY[2] =CFY3;
  CFY[3] =CFY4;
  CFY[5] =CFY5;
  CFY[6] =CFY6;
  CFY[7] =CFY7;
  CFY[8] =CFY8;
}
void af_G(int CFG1,int CFG2,int CFG3,int CFG4,int CFG5,int CFG6,int CFG7,int CFG8){
  CFG[0] =CFG1;
  CFG[1] =CFG2;
  CFG[2] =CFG3;
  CFG[3] =CFG4;
  CFG[5] =CFG5;
  CFG[6] =CFG6;
  CFG[7] =CFG7;
  CFG[8] =CFG8;
}
void af_B(int CFB1,int CFB2,int CFB3,int CFB4,int CFB5,int CFB6,int CFB7,int CFB8){
  CFB[0] =CFB1;
  CFB[1] =CFB2;
  CFB[2] =CFB3;
  CFB[3] =CFB4;
  CFB[5] =CFB5;
  CFB[6] =CFB6;
  CFB[7] =CFB7;
  CFB[8] =CFB8;
}
void af_R(int CFR1,int CFR2,int CFR3,int CFR4,int CFR5,int CFR6,int CFR7,int CFR8){
  CFR[0] =CFR1;
  CFR[1] =CFR2;
  CFR[2] =CFR3;
  CFR[3] =CFR4;
  CFR[5] =CFR5;
  CFR[6] =CFR6;
  CFR[7] =CFR7;
  CFR[8] =CFR8;
}
void af_O(int CFO1,int CFO2,int CFO3,int CFO4,int CFO5,int CFO6,int CFO7,int CFO8){
  CFO[0] =CFO1;
  CFO[1] =CFO2;
  CFO[2] =CFO3;
  CFO[3] =CFO4;
  CFO[5] =CFO5;
  CFO[6] =CFO6;
  CFO[7] =CFO7;
  CFO[8] =CFO8;
}

//restituizione valori
int mosse(){                     //restituisce il numero di mosse
  return numero404notfound;
}
int errori(){                    //restituisce il valore di errore (0 nessun errore)
  return er404notfound;
}
int mossa(int nmnm){             //restituisce un numero che sta ad indicare la mossa nella posizione del numero dato in ingresso
  if(nmnm < 1 || nmnm > numero404notfound) return 0;
  return alg[nmnm-1];
}
int tempo(){                     //restituisce un numero che sta ad indicare il tempo in millisecondi impiegato per eseguire la risoluzione
  return temp_init;
}
//start processo
void start(){                    //richiamando questa funzione verrà avviata la risoluzione
  temp_init=millis();
  risoluzione();
  for (int k = 0; k <= 8; k++) {
    CFW[k] = 0;
    CFY[k] = 0;
    CFG[k] = 0;
    CFB[k] = 0;
    CFR[k] = 0;
    CFO[k] = 0;
  }
  CFW[4] = 1;
  CFY[4] = 2;
  CFG[4] = 3;
  CFB[4] = 4;
  CFR[4] = 5;
  CFO[4] = 6;
  temp_init=millis()-temp_init;
}

// ============================================================================
//  Risolutore
// ============================================================================
#pragma GCC push_options
#pragma GCC optimize ("O3")
//profondita' massima fino a cui si costruiscono le tabelle di pruning (fase 1 / fase 2): le distanze piu' grandi
//sono sostituite da limite+1 (stima per difetto, quindi la ricerca resta corretta) e la costruzione e' ~40% piu' veloce
#define CUBEX_P1_CUT 5
#define CUBEX_P2_CUT 9
namespace {

//Facce interne: U=0 R=1 F=2 D=3 L=4 B=5.  Colori dello sketch: 1=W(U) 2=Y(D) 3=G(F) 4=B(B) 5=R(R) 6=O(L)
const uint8_t COL2FAC[7] = {255, 0, 3, 2, 5, 1, 4};
const uint8_t BLK2FAC[6] = {0, 3, 2, 5, 1, 4};   //ordine dei blocchi W,Y,G,B,R,O -> faccia interna

//posizione degli adesivi (indice = blocco*9+posizione) di ogni angolo/spigolo
static const uint8_t CF[8][3] = {
  {8,36,20},
  {6,18,47},
  {0,45,29},
  {2,27,38},
  {11,26,42},
  {9,53,24},
  {15,35,51},
  {17,44,33}
};
static const uint8_t EF[12][2] = {
  {5,37},
  {7,19},
  {3,46},
  {1,28},
  {14,43},
  {10,25},
  {12,52},
  {16,34},
  {23,39},
  {21,50},
  {32,48},
  {30,41}
};
static const uint8_t MVF[6][54] = {
  {6,3,0,7,4,1,8,5,2,9,10,11,12,13,14,15,16,17,36,37,38,21,22,23,24,25,26,45,46,47,30,31,32,33,34,35,27,28,29,39,40,41,42,43,44,18,19,20,48,49,50,51,52,53},
  {0,1,20,3,4,23,6,7,26,9,10,33,12,13,30,15,16,27,18,19,11,21,22,14,24,25,17,8,28,29,5,31,32,2,34,35,42,39,36,43,40,37,44,41,38,45,46,47,48,49,50,51,52,53},
  {0,1,2,3,4,5,53,50,47,42,39,36,12,13,14,15,16,17,24,21,18,25,22,19,26,23,20,27,28,29,30,31,32,33,34,35,6,37,38,7,40,41,8,43,44,45,46,9,48,49,10,51,52,11},
  {0,1,2,3,4,5,6,7,8,15,12,9,16,13,10,17,14,11,18,19,20,21,22,23,51,52,53,27,28,29,30,31,32,42,43,44,36,37,38,39,40,41,24,25,26,45,46,47,48,49,50,33,34,35},
  {35,1,2,32,4,5,29,7,8,18,10,11,21,13,14,24,16,17,0,19,20,3,22,23,6,25,26,27,28,15,30,31,12,33,34,9,36,37,38,39,40,41,42,43,44,51,48,45,52,49,46,53,50,47},
  {38,41,44,3,4,5,6,7,8,9,10,11,12,13,14,45,48,51,18,19,20,21,22,23,24,25,26,33,30,27,34,31,28,35,32,29,36,37,17,39,40,16,42,43,15,2,46,47,1,49,50,0,52,53}
};

static const uint8_t RP[2][54] = {
  {51,48,45,52,49,46,53,50,47,42,39,36,43,40,37,44,41,38,24,21,18,25,22,19,26,23,20,29,32,35,28,31,34,27,30,33,6,3,0,7,4,1,8,5,2,15,12,9,16,13,10,17,14,11},
  {35,34,33,32,31,30,29,28,27,18,19,20,21,22,23,24,25,26,0,1,2,3,4,5,6,7,8,17,16,15,14,13,12,11,10,9,38,41,44,37,40,43,36,39,42,51,48,45,52,49,46,53,50,47}
};
static const uint8_t RFM[2][6] = {{4,0,2,1,3,5},{5,1,0,2,4,3}};
static const uint8_t RINV[3][6] = {{0,1,2,3,4,5},{1,3,2,4,0,5},{2,1,3,5,4,0}};

const uint8_t CCOL[8][3] = {{0,1,2},{0,2,4},{0,4,5},{0,5,1},{3,2,1},{3,4,2},{3,5,4},{3,1,5}};
const uint8_t ECOL[12][2] = {{0,1},{0,2},{0,4},{0,5},{3,1},{3,2},{3,4},{3,5},{2,1},{2,4},{5,4},{5,1}};
const uint16_t FACT8[8] = {1,1,2,6,24,120,720,5040};
//codici mossa dello sketch
const uint8_t CODE_Q[6] = {1,5,9,3,7,11};      //mossa oraria per faccia interna (antioraria = +1)
const uint8_t CODE_H[6] = {13,15,17,14,16,18}; //mezzo giro
const uint8_t P2MOV[10] = {0,1,2,9,10,11,4,7,13,16};

struct Cubo { uint8_t cp[8], co[8], ep[12], eo[12]; };
struct S1 { uint8_t co[8]; uint8_t eo[12]; uint8_t pos[4]; };
struct S2 { uint8_t cp[8]; uint8_t ep[12]; uint8_t par; };

Cubo MV[18];            //mosse sul cubo (faccia*3 + potenza-1)
uint8_t MPOS[18][12];   //nuova posizione di uno spigolo che si trova nello slot s
uint8_t PIDX[12][12];   //indice della coppia non ordinata di posizioni
uint8_t PAIR[66][2];
uint8_t SL2M[18][66];
bool movesReady = false;
uint8_t LTC[8][256];   //LTC[x][visti] = quanti valori minori di x non sono ancora stati visti

uint8_t *T1 = 0, *T2 = 0, *T3 = 0, *T4 = 0;   //tabelle di pruning (4 bit per valore)
const uint32_t N1 = 2187UL * 66UL;
const uint32_t N2 = 2048UL * 66UL;
const uint32_t N3 = 40320UL;   //x nCls (1 o 2) voci per le tabelle di fase 2
#ifndef CUBEX_CAP_F2
#define CUBEX_CAP_F2 13   //profondita' massima della fase 2 finche' non c'e' nessuna soluzione
#endif

Cubo base[6];      //3 orientazioni del cubo (assi U/D, R/L, F/B) x (cubo, cubo inverso)
int curStream, nCls;
uint8_t path1[32];
uint8_t path2[32];
int bestLen, curL1;
uint8_t bestSol[40];
bool haveSol, stopAll;
uint32_t tDeadline, tUltimo;   //scadenza totale, istante dell'ultima soluzione trovata
uint32_t nodeCnt;

inline uint8_t nget(const uint8_t* t, uint32_t i) { uint8_t v = t[i >> 1]; return (i & 1) ? (v >> 4) : (v & 15); }
inline void nset(uint8_t* t, uint32_t i, uint8_t val) {
  if (i & 1) t[i >> 1] = (t[i >> 1] & 0x0F) | (val << 4);
  else t[i >> 1] = (t[i >> 1] & 0xF0) | val;
}

//---------------------------------------------------------------- cubie <-> facelet
int facToCubo(const uint8_t* fc, Cubo& c) {
  uint8_t usedC = 0; uint16_t usedE = 0;
  for (int j = 0; j < 8; j++) {
    int o = -1;
    for (int k = 0; k < 3; k++) { uint8_t f = fc[CF[j][k]]; if (f == 0 || f == 3) { o = k; break; } }
    if (o < 0) return 3;
    uint8_t x = fc[CF[j][o]], y2 = fc[CF[j][(o + 1) % 3]], z = fc[CF[j][(o + 2) % 3]];
    int found = -1;
    for (int i = 0; i < 8; i++) if (CCOL[i][0] == x && CCOL[i][1] == y2 && CCOL[i][2] == z) { found = i; break; }
    if (found < 0 || (usedC & (1 << found))) return 3;
    usedC |= (1 << found);
    c.cp[j] = found; c.co[j] = o;
  }
  for (int j = 0; j < 12; j++) {
    uint8_t a = fc[EF[j][0]], bb = fc[EF[j][1]];
    int found = -1, fl = 0;
    for (int i = 0; i < 12; i++) {
      if (ECOL[i][0] == a && ECOL[i][1] == bb) { found = i; fl = 0; break; }
      if (ECOL[i][0] == bb && ECOL[i][1] == a) { found = i; fl = 1; break; }
    }
    if (found < 0 || (usedE & (1 << found))) return 2;
    usedE |= (1 << found);
    c.ep[j] = found; c.eo[j] = fl;
  }
  return 0;
}

int validaCubo(const Cubo& c) {
  int s = 0;
  for (int i = 0; i < 8; i++) s += c.co[i];
  if (s % 3) return 5;
  s = 0;
  for (int i = 0; i < 12; i++) s += c.eo[i];
  if (s & 1) return 4;
  int pc = 0, pe = 0;
  for (int i = 0; i < 8; i++) for (int j = i + 1; j < 8; j++) if (c.cp[i] > c.cp[j]) pc ^= 1;
  for (int i = 0; i < 12; i++) for (int j = i + 1; j < 12; j++) if (c.ep[i] > c.ep[j]) pe ^= 1;
  if (pc != pe) return 6;
  return 0;
}

inline void applica(const Cubo& a, const Cubo& m, Cubo& rr) {
  for (int i = 0; i < 8; i++) {
    uint8_t s = m.cp[i];
    rr.cp[i] = a.cp[s];
    uint8_t t = a.co[s] + m.co[i];
    rr.co[i] = (t >= 3) ? t - 3 : t;
  }
  for (int i = 0; i < 12; i++) {
    uint8_t s = m.ep[i];
    rr.ep[i] = a.ep[s];
    rr.eo[i] = a.eo[s] ^ m.eo[i];
  }
}

void inverso(const Cubo& a, Cubo& rr) {
  for (int i = 0; i < 8; i++) { rr.cp[a.cp[i]] = i; rr.co[a.cp[i]] = (3 - a.co[i]) % 3; }
  for (int i = 0; i < 12; i++) { rr.ep[a.ep[i]] = i; rr.eo[a.ep[i]] = a.eo[i]; }
}

bool risolto(const Cubo& c) {
  for (int i = 0; i < 8; i++) if (c.cp[i] != i || c.co[i]) return false;
  for (int i = 0; i < 12; i++) if (c.ep[i] != i || c.eo[i]) return false;
  return true;
}

void costruisciMosse() {
  if (movesReady) return;
  uint8_t fc[54], cur[54], nw[54];
  for (int k = 0; k < 54; k++) fc[k] = BLK2FAC[k / 9];
  for (int f = 0; f < 6; f++) {
    memcpy(cur, fc, 54);
    for (int p = 0; p < 3; p++) {
      for (int t = 0; t < 54; t++) nw[t] = cur[MVF[f][t]];
      memcpy(cur, nw, 54);
      facToCubo(cur, MV[f * 3 + p]);
    }
  }
  for (int m = 0; m < 18; m++) for (int i = 0; i < 12; i++) MPOS[m][MV[m].ep[i]] = i;
  int n = 0;
  for (int p = 0; p < 12; p++) for (int q = p + 1; q < 12; q++) {
    PIDX[p][q] = PIDX[q][p] = n; PAIR[n][0] = p; PAIR[n][1] = q; n++;
  }
  for (int m = 0; m < 18; m++) for (int s = 0; s < 66; s++) SL2M[m][s] = PIDX[MPOS[m][PAIR[s][0]]][MPOS[m][PAIR[s][1]]];
  for (int x = 0; x < 8; x++) for (int m = 0; m < 256; m++) {
    int c = x;
    for (int j = 0; j < x; j++) if (m & (1 << j)) c--;
    LTC[x][m] = c;
  }
  movesReady = true;
}

//---------------------------------------------------------------- permutazioni
inline uint16_t rank8(const uint8_t* a) {
  uint8_t seen = 0; uint16_t rk = 0;
  for (int i = 0; i < 7; i++) {
    uint8_t x = a[i];
    rk += LTC[x][seen] * FACT8[7 - i];
    seen |= 1 << x;
  }
  return rk;
}
void unrank8(uint16_t rk, uint8_t* a) {
  uint8_t av[8] = {0,1,2,3,4,5,6,7};
  int n = 8;
  for (int i = 0; i < 8; i++) {
    uint16_t f = FACT8[7 - i];
    uint8_t d = rk / f; rk %= f;
    a[i] = av[d];
    for (int j = d; j < n - 1; j++) av[j] = av[j + 1];
    n--;
  }
}

//---------------------------------------------------------------- tabelle di pruning
uint8_t* allocaTab(uint32_t entries) {
  uint32_t by = (entries + 1) / 2;
#ifdef CUBEX_ESP32
  //RAM interna: se la scheda ha la PSRAM, malloc() metterebbe qui le tabelle in PSRAM (molto piu' lenta per accessi casuali)
  uint8_t* p = (uint8_t*)heap_caps_malloc(by, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (!p) p = (uint8_t*)malloc(by);
#else
  uint8_t* p = (uint8_t*)malloc(by);
#endif
  if (p) memset(p, 0xFF, by);
  return p;
}
void liberaTabelle() {
  if (T1) free(T1);
  if (T2) free(T2);
  if (T3) free(T3);
  if (T4) free(T4);
  T1 = T2 = T3 = T4 = 0;
}

void nextTwist(uint16_t a, uint16_t* out) {
  uint8_t d[8]; int s = 0;
  for (int i = 0; i < 7; i++) { d[i] = a % 3; a /= 3; s += d[i]; }
  d[7] = (3 - s % 3) % 3;
  for (int m = 0; m < 18; m++) {
    uint16_t v = 0, pw = 1;
    for (int i = 0; i < 7; i++) { v += ((d[MV[m].cp[i]] + MV[m].co[i]) % 3) * pw; pw *= 3; }
    out[m] = v;
  }
}
void nextFlip(uint16_t a, uint16_t* out) {
  uint8_t e[12]; int s = 0;
  for (int i = 0; i < 11; i++) { e[i] = (a >> i) & 1; s += e[i]; }
  e[11] = s & 1;
  for (int m = 0; m < 18; m++) {
    uint16_t v = 0;
    for (int i = 0; i < 11; i++) v |= (uint16_t)(e[MV[m].ep[i]] ^ MV[m].eo[i]) << i;
    out[m] = v;
  }
}

//le voci mai raggiunte (distanza maggiore del limite di costruzione) valgono limite+1: stima per difetto, quindi ancora valida
void riempi(uint8_t* T, uint32_t n, uint8_t v) {
  for (uint32_t i = 0; i < n; i++) if (nget(T, i) == 15) nset(T, i, v);
}

//orientamento (angoli o spigoli) x posizione di una coppia di spigoli della fetta
void buildP1(uint8_t* T, uint16_t nA, bool twist) {
  for (int s = 0; s < 66; s++) if (PAIR[s][0] >= 8 && PAIR[s][1] >= 8) nset(T, s, 0);   //a=0
  uint16_t nxt[18];
  for (uint8_t d = 1; d <= CUBEX_P1_CUT; d++) {
    bool found = false;
    for (uint16_t a = 0; a < nA; a++) {
      uint32_t row = (uint32_t)a * 66;
      bool any = false;
      for (int s = 0; s < 66; s++) if (nget(T, row + s) == d - 1) { any = true; break; }
      if (!any) continue;
      if (twist) nextTwist(a, nxt); else nextFlip(a, nxt);
      for (int s = 0; s < 66; s++) if (nget(T, row + s) == d - 1)
        for (int m = 0; m < 18; m++) {
          uint32_t t = (uint32_t)nxt[m] * 66 + SL2M[m][s];
          if (nget(T, t) == 15) { nset(T, t, d); found = true; }
        }
    }
    if (!found) break;
  }
  riempi(T, (uint32_t)nA * 66, CUBEX_P1_CUT + 1);
}

//fase 2: permutazione degli angoli (corner=true) oppure dei soli 8 spigoli U/D,
//combinata (se nCls==2) con la parita' della permutazione degli spigoli di fetta
void buildP2(uint8_t* T, bool corner) {
  nset(T, 0, 0);
  uint8_t p[8], n[8];
  for (uint8_t d = 1; d <= CUBEX_P2_CUT; d++) {
    bool found = false;
    for (uint32_t rk = 0; rk < N3; rk++) {
      bool a0 = nget(T, rk * nCls) == d - 1;
      bool a1 = (nCls == 2) && nget(T, rk * 2 + 1) == d - 1;
      if (!a0 && !a1) continue;
      unrank8(rk, p);                           //una sola volta per entrambe le classi di parita'
      for (int k = 0; k < 10; k++) {
        const Cubo& m = MV[P2MOV[k]];
        const uint8_t* mp = corner ? m.cp : m.ep;
        for (int i = 0; i < 8; i++) n[i] = p[mp[i]];
        uint32_t t = (uint32_t)rank8(n) * nCls;
        int fl = 0;
        if (nCls == 2) { int f = P2MOV[k] / 3; fl = (f == 1 || f == 2 || f == 4 || f == 5) ? 1 : 0; }
        if (a0) { uint32_t u = t + fl; if (nget(T, u) == 15) { nset(T, u, d); found = true; } }
        if (a1) { uint32_t u = t + (1 ^ fl); if (nget(T, u) == 15) { nset(T, u, d); found = true; } }
      }
    }
    if (!found) break;
  }
  riempi(T, (uint32_t)N3 * nCls, CUBEX_P2_CUT + 1);
}

bool costruisciTabelle() {
  costruisciMosse();
  T1 = allocaTab(N1); T2 = allocaTab(N2);
  if (!T1 || !T2) { liberaTabelle(); return false; }
  nCls = 2;
  T3 = allocaTab(N3 * 2); T4 = allocaTab(N3 * 2);
  if (!T3 || !T4) {              //poca memoria: tabelle di fase 2 piu' piccole (e ricerca piu' lenta)
    if (T3) free(T3);
    if (T4) free(T4);
    nCls = 1;
    T3 = allocaTab(N3); T4 = allocaTab(N3);
    if (!T3 || !T4) { liberaTabelle(); return false; }
  }
  buildP1(T1, 2187, true);
  buildP1(T2, 2048, false);
  buildP2(T3, true);
  buildP2(T4, false);
  return true;
}

//---------------------------------------------------------------- ricerca
inline bool tempoFinito() {
  uint32_t t = (uint32_t)millis();
  return (int32_t)(t - tDeadline) >= 0 || (uint32_t)(t - tUltimo) >= CUBEX_TEMPO_MIGLIORAMENTO_MS;
}
inline bool tempoScaduto() {
  nodeCnt++;
  if ((nodeCnt & 0x3FF) == 0) {
    yield();
    if (haveSol && tempoFinito()) stopAll = true;
  }
  return stopAll;
}

//fase 2: soluzione dentro il gruppo <U,D,R2,L2,F2,B2>
bool dfs2(const S2& s, int d, int last, int depth) {
  if (d == 0) {
    return s.ep[8] == 8 && s.ep[9] == 9 && s.ep[10] == 10 && s.ep[11] == 11 && rank8(s.cp) == 0 && rank8(s.ep) == 0;
  }
  if (tempoScaduto()) return false;
  for (int k = 0; k < 10; k++) {
    int m = P2MOV[k], f = m / 3;
    if (f == last || (last >= 0 && f % 3 == last % 3 && f < last)) continue;
    const Cubo& mv = MV[m];
    S2 n;
    n.par = s.par ^ ((f == 1 || f == 2 || f == 4 || f == 5) ? 1 : 0);
    for (int i = 0; i < 8; i++) n.cp[i] = s.cp[mv.cp[i]];
    uint8_t h3 = nget(T3, (uint32_t)rank8(n.cp) * nCls + (nCls == 2 ? n.par : 0));
    if (h3 > d - 1) continue;
    for (int i = 0; i < 12; i++) n.ep[i] = s.ep[mv.ep[i]];
    uint8_t h4 = nget(T4, (uint32_t)rank8(n.ep) * nCls + (nCls == 2 ? n.par : 0));
    if (h4 > d - 1) continue;
    path2[depth] = m;
    if (dfs2(n, d - 1, f, depth + 1)) return true;
    if (stopAll) return false;
  }
  return false;
}

void registraSoluzione(int L1, int L2) {
  int tot = L1 + L2;
  uint8_t seq[40];
  for (int i = 0; i < L1; i++) seq[i] = path1[i];
  for (int i = 0; i < L2; i++) seq[L1 + i] = path2[i];
  int fr = curStream >> 1;
  for (int i = 0; i < tot; i++) {
    uint8_t m = (curStream & 1) ? seq[tot - 1 - i] : seq[i];      //cubo inverso: sequenza al contrario...
    if (curStream & 1) m = (m / 3) * 3 + (2 - m % 3);              //...e con le mosse invertite
    bestSol[i] = RINV[fr][m / 3] * 3 + (m % 3);                    //torna al sistema di riferimento originale
  }
  bestLen = tot;
  haveSol = true;
  tUltimo = (uint32_t)millis();   //riparte il tempo concesso per trovare una soluzione migliore
}

void foglia(int L1, int last) {
  int maxd = bestLen - L1 - 1;
  if (maxd > 18) maxd = 18;
  if (!haveSol && L1 < 14 && maxd > CUBEX_CAP_F2) maxd = CUBEX_CAP_F2;
  if (maxd < 0) return;
  Cubo c = base[curStream], t;
  for (int i = 0; i < L1; i++) { applica(c, MV[path1[i]], t); c = t; }
  S2 s;
  for (int i = 0; i < 8; i++) s.cp[i] = c.cp[i];
  for (int i = 0; i < 12; i++) s.ep[i] = c.ep[i];
  s.par = 0;
  { int inv = 0; for (int i = 8; i < 12; i++) for (int j = i + 1; j < 12; j++) if (c.ep[i] > c.ep[j]) inv ^= 1; s.par = inv; }
  for (int d2 = 0; d2 <= maxd; d2++) {
    if (dfs2(s, d2, last, 0)) { registraSoluzione(L1, d2); return; }
    if (stopAll) return;
  }
}

inline bool goal1(const S1& s) {
  for (int i = 0; i < 8; i++) if (s.co[i]) return false;
  for (int i = 0; i < 12; i++) if (s.eo[i]) return false;
  return s.pos[0] >= 8 && s.pos[1] >= 8 && s.pos[2] >= 8 && s.pos[3] >= 8;
}
inline uint16_t twistOf(const S1& s) { uint16_t v = 0; for (int i = 6; i >= 0; i--) v = v * 3 + s.co[i]; return v; }
inline uint16_t flipOf(const S1& s) { uint16_t v = 0; for (int i = 10; i >= 0; i--) v = (v << 1) | s.eo[i]; return v; }
inline uint8_t hOf(const S1& s) {
  uint8_t h1 = nget(T1, (uint32_t)twistOf(s) * 66 + PIDX[s.pos[0]][s.pos[1]]);
  uint8_t h2 = nget(T2, (uint32_t)flipOf(s) * 66 + PIDX[s.pos[2]][s.pos[3]]);
  return h1 > h2 ? h1 : h2;
}

//fase 1: porta il cubo nel gruppo G1 (angoli e spigoli orientati, spigoli di fetta nella fetta)
void dfs1(const S1& s, int d, int last, int depth) {
  if (d == 0) {
    if (goal1(s)) foglia(depth, last);
    return;
  }
  if (tempoScaduto()) return;
  for (int m = 0; m < 18; m++) {
    int f = m / 3, p = m % 3;
    if (f == last || (last >= 0 && f % 3 == last % 3 && f < last)) continue;
    if (d == 1 && (f == 0 || f == 3 || p == 1)) continue;   //l'ultima mossa della fase 1 non puo' stare in G1
    const Cubo& mv = MV[m];
    S1 n;
    for (int i = 0; i < 8; i++) { uint8_t t = s.co[mv.cp[i]] + mv.co[i]; n.co[i] = (t >= 3) ? t - 3 : t; }
    for (int i = 0; i < 4; i++) n.pos[i] = MPOS[m][s.pos[i]];
    if (nget(T1, (uint32_t)twistOf(n) * 66 + PIDX[n.pos[0]][n.pos[1]]) > d - 1) continue;
    for (int i = 0; i < 12; i++) n.eo[i] = s.eo[mv.ep[i]] ^ mv.eo[i];
    if (nget(T2, (uint32_t)flipOf(n) * 66 + PIDX[n.pos[2]][n.pos[3]]) > d - 1) continue;
    path1[depth] = m;
    dfs1(n, d - 1, f, depth + 1);
    if (stopAll) return;
  }
}

void unisciMosse(uint8_t* mv, int& n) {   //elimina mosse ridondanti (U U' -> nulla, U U -> U2, ...)
  bool changed = true;
  while (changed) {
    changed = false;
    for (int i = 0; i + 1 < n && !changed; i++) {
      int j = -1;
      if (mv[i] / 3 == mv[i + 1] / 3) j = i + 1;
      else if (i + 2 < n && mv[i] / 3 == mv[i + 2] / 3 && mv[i] / 3 % 3 == mv[i + 1] / 3 % 3) j = i + 2;
      if (j < 0) continue;
      int tot = ((mv[i] % 3 + 1) + (mv[j] % 3 + 1)) & 3;
      int f = mv[i] / 3;
      if (tot == 0) {
        for (int k = j; k + 1 < n; k++) mv[k] = mv[k + 1];
        n--;
        for (int k = i; k + 1 < n; k++) mv[k] = mv[k + 1];
        n--;
      } else {
        mv[i] = f * 3 + (tot - 1);
        for (int k = j; k + 1 < n; k++) mv[k] = mv[k + 1];
        n--;
      }
      changed = true;
    }
  }
}

}  // namespace
#pragma GCC pop_options

void risoluzione() {
  unsigned long t0 = millis();   //istante di inizio del calcolo
  numero404notfound = 0;
  er404notfound = 0;
  for (int i = 0; i < 255; i++) alg[i] = 0;

  //controllo colori e conversione in angoli/spigoli
  const int* faces[6] = {CFW, CFY, CFG, CFB, CFR, CFO};
  uint8_t fc[54], fr2[54];
  int cnt[7] = {0,0,0,0,0,0,0};
  for (int k = 0; k < 6; k++) for (int i = 0; i < 9; i++) {
    int v = faces[k][i];
    if (v < 1 || v > 6) { er404notfound = 1; return; }
    cnt[v]++;
    fc[k * 9 + i] = COL2FAC[v];
  }
  for (int v = 1; v <= 6; v++) if (cnt[v] != 9) { er404notfound = 1; return; }
  costruisciMosse();
  Cubo c0;
  int e = facToCubo(fc, c0);
  if (e == 0) e = validaCubo(c0);
  if (e) { er404notfound = e; return; }

  //tabelle
  if (!costruisciTabelle()) { er404notfound = 7; return; }

  //le 6 ricerche: cubo ruotato in modo che l'asse U/D, R/L o F/B faccia da asse della fase 1, e relativo cubo inverso
  base[0] = c0;
  inverso(c0, base[1]);
  for (int a = 1; a < 3; a++) {
    for (int k = 0; k < 54; k++) fr2[RP[a - 1][k]] = RFM[a - 1][fc[k]];
    Cubo cr;
    facToCubo(fr2, cr);
    base[2 * a] = cr;
    inverso(cr, base[2 * a + 1]);
  }

  tDeadline = (uint32_t)t0 + CUBEX_TEMPO_MAX_MS;
  tUltimo = (uint32_t)t0;
  bestLen = 31; haveSol = false; stopAll = false; nodeCnt = 0;
  for (int L1 = 0; L1 < bestLen && !stopAll; L1++) {
    for (int st = 0; st < 6 && !stopAll; st++) {
      curStream = st; curL1 = L1;
      S1 s;
      for (int i = 0; i < 8; i++) s.co[i] = base[st].co[i];
      for (int i = 0; i < 12; i++) s.eo[i] = base[st].eo[i];
      for (int k = 0; k < 4; k++) { uint8_t cb = 8 + k; for (int i = 0; i < 12; i++) if (base[st].ep[i] == cb) s.pos[k] = i; }
      if (hOf(s) > L1) continue;
      if (L1 == 0) { if (goal1(s)) foglia(0, -1); }
      else dfs1(s, L1, -1, 0);
    }
    if (haveSol && tempoFinito()) break;
  }
  liberaTabelle();

  if (!haveSol) { er404notfound = 8; return; }
  uint8_t sol[40];
  int n = bestLen;
  for (int i = 0; i < n; i++) sol[i] = bestSol[i];
  unisciMosse(sol, n);

  //verifica finale sul cubo originale
  Cubo c = c0, t;
  for (int i = 0; i < n; i++) { applica(c, MV[sol[i]], t); c = t; }
  if (!risolto(c)) { er404notfound = 8; return; }

  for (int i = 0; i < n; i++) {
    int f = sol[i] / 3, p = sol[i] % 3;
    alg[i] = (p == 1) ? CODE_H[f] : (CODE_Q[f] + (p == 2 ? 1 : 0));
  }
  numero404notfound = n;
}

//funzioni per gli stepper
void stepper_init(int sdapin, int sclpin, int adr1, int adr2, int adr3){    //funzione per inizializzare i motori stepper e i loro pin
  adrs1 = adr1,
  Wire.begin(sdapin, sclpin);
  Wire.beginTransmission(adrs1);
  Wire.write((byte)0b11111111);
  Wire.endTransmission();
  adrs2 = adr2,
  Wire.beginTransmission(adrs2);
  Wire.write((byte)0b11111111);
  Wire.endTransmission();
  adrs3 = adr3,
  Wire.beginTransmission(adrs3);
  Wire.write((byte)0b11111111);
  Wire.endTransmission();
}
void stepper_RPM(int speed){                            //funzione per impostare la velocità dei motori
  tempostep = 300000 / speed;
}
void stepper_LUN(int lunghezzamossa){                   //funzione per impostare gli step da fare per mossa
  lunghe = lunghezzamossa;
  if(lunghe > 0){
    dir404=1;
  }else if(lunghe < 0){
    dir404=0;
  }else{
    dir404=2;
  }

}
void step_U(){                                                 //funzione per richiamare una determinata  mossa
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SU++;
      if(SU > 3){
        SU=0;
      }
      movu();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SU--;
      if(SU < 0){
        SU=3;
      }
      movu();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Upin1 = 1;
  Upin2 = 1;
  Upin3 = 1;
  Upin4 = 1;
  aggexp();
}
void step_D(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SD++;
      if(SD > 3){
        SD=0;
      }
      movd();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SD--;
      if(SD < 0){
        SD=3;
      }
      movd();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Dpin1 = 1;
  Dpin2 = 1;
  Dpin3 = 1;
  Dpin4 = 1;
  aggexp();
}
void step_R(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SR++;
      if(SR > 3){
        SR=0;
      }
      movr();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SR--;
      if(SR < 0){
        SR=3;
      }
      movr();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Rpin1 = 1;
  Rpin2 = 1;
  Rpin3 = 1;
  Rpin4 = 1;
  aggexp();
}
void step_L(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SL++;
      if(SL > 3){
        SL=0;
      }
      movl();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SL--;
      if(SL < 0){
        SL=3;
      }
      movl();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Lpin1 = 1;
  Lpin2 = 1;
  Lpin3 = 1;
  Lpin4 = 1;
  aggexp();
}
void step_F(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SF++;
      if(SF > 3){
        SF=0;
      }
      movf();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SF--;
      if(SF < 0){
        SF=3;
      }
      movf();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Fpin1 = 1;
  Fpin2 = 1;
  Fpin3 = 1;
  Fpin4 = 1;
  aggexp();
}
void step_B(){
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SB++;
      if(SB > 3){
        SB=0;
      }
      movb();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SB--;
      if(SB < 0){
        SB=3;
      }
      movb();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Bpin1 = 1;
  Bpin2 = 1;
  Bpin3 = 1;
  Bpin4 = 1;
  aggexp();
}
void step_CUS(){                                               //funzione per richiamare una mossa custom che muove U e D nel senso opposto
  if(dir404==1){
    t_init = micros();
    for(cicli1=1; cicli1<=lunghe; cicli1++){
      SU++;
      if(SU > 3){
        SU=0;
      }
      SD--;
      if(SD < 0){
        SD=3;
      }
      movu();
      movd();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  if(dir404==0){
    t_init = micros();
    
    for(cicli1=-1; cicli1>=lunghe; cicli1--){
      SU--;
      if(SU < 0){
        SU=3;
      }
      SD++;
      if(SD > 3){
        SD=0;
      }
      movu();
      movd();
      aggexp();
      while(micros() - t_init <= tempostep){}
      t_init = micros();
    }
  }
  Upin1 = 1;
  Upin2 = 1;
  Upin3 = 1;
  Upin4 = 1;
  Dpin1 = 1;
  Dpin2 = 1;
  Dpin3 = 1;
  Dpin4 = 1;
  aggexp();
}
void movu(){
  if(SU==0){
    Upin1 = 0;
    Upin2 = 1;
    Upin3 = 0;
    Upin4 = 1;
  }
  if(SU==1){
    Upin1 = 1;
    Upin2 = 0;
    Upin3 = 0;
    Upin4 = 1;
  }
  if(SU==2){
    Upin1 = 1;
    Upin2 = 0;
    Upin3 = 1;
    Upin4 = 0;
  }
  if(SU==3){
    Upin1 = 0;
    Upin2 = 1;
    Upin3 = 1;
    Upin4 = 0;
  }
}
void movd(){
  if(SD==0){
    Dpin1 = 0;
    Dpin2 = 1;
    Dpin3 = 0;
    Dpin4 = 1;
  }
  if(SD==1){
    Dpin1 = 1;
    Dpin2 = 0;
    Dpin3 = 0;
    Dpin4 = 1;
  }
  if(SD==2){
    Dpin1 = 1;
    Dpin2 = 0;
    Dpin3 = 1;
    Dpin4 = 0;
  }
  if(SD==3){
    Dpin1 = 0;
    Dpin2 = 1;
    Dpin3 = 1;
    Dpin4 = 0;
  }
}
void movr(){
  if(SR==0){
    Rpin1 = 0;
    Rpin2 = 1;
    Rpin3 = 0;
    Rpin4 = 1;
  }
  if(SR==1){
    Rpin1 = 1;
    Rpin2 = 0;
    Rpin3 = 0;
    Rpin4 = 1;
  }
  if(SR==2){
    Rpin1 = 1;
    Rpin2 = 0;
    Rpin3 = 1;
    Rpin4 = 0;
  }
  if(SR==3){
    Rpin1 = 0;
    Rpin2 = 1;
    Rpin3 = 1;
    Rpin4 = 0;
  }
}
void movl(){
  if(SL==0){
    Lpin1 = 0;
    Lpin2 = 1;
    Lpin3 = 0;
    Lpin4 = 1;
  }
  if(SL==1){
    Lpin1 = 1;
    Lpin2 = 0;
    Lpin3 = 0;
    Lpin4 = 1;
  }
  if(SL==2){
    Lpin1 = 1;
    Lpin2 = 0;
    Lpin3 = 1;
    Lpin4 = 0;
  }
  if(SL==3){
    Lpin1 = 0;
    Lpin2 = 1;
    Lpin3 = 1;
    Lpin4 = 0;
  }
}
void movf(){
  if(SF==0){
    Fpin1 = 0;
    Fpin2 = 1;
    Fpin3 = 0;
    Fpin4 = 1;
  }
  if(SF==1){
    Fpin1 = 1;
    Fpin2 = 0;
    Fpin3 = 0;
    Fpin4 = 1;
  }
  if(SF==2){
    Fpin1 = 1;
    Fpin2 = 0;
    Fpin3 = 1;
    Fpin4 = 0;
  }
  if(SF==3){
    Fpin1 = 0;
    Fpin2 = 1;
    Fpin3 = 1;
    Fpin4 = 0;
  }
}
void movb(){
  if(SB==0){
    Bpin1 = 0;
    Bpin2 = 1;
    Bpin3 = 0;
    Bpin4 = 1;
  }
  if(SB==1){
    Bpin1 = 1;
    Bpin2 = 0;
    Bpin3 = 0;
    Bpin4 = 1;
  }
  if(SB==2){
    Bpin1 = 1;
    Bpin2 = 0;
    Bpin3 = 1;
    Bpin4 = 0;
  }
  if(SB==3){
    Bpin1 = 0;
    Bpin2 = 1;
    Bpin3 = 1;
    Bpin4 = 0;
  }
}
void aggexp(){
  exp1 = (Dpin4*128) + (Dpin3*64) + (Dpin2*32) + (Dpin1*16) + (Upin4*8) + (Upin3*4) + (Upin2*2) + Upin1;
  Wire.beginTransmission(adrs1);
  Wire.write(exp1);
  Wire.endTransmission();
  exr2 = (Lpin4*128) + (Lpin3*64) + (Lpin2*32) + (Lpin1*16) + (Rpin4*8) + (Rpin3*4) + (Rpin2*2) + Rpin1;
  Wire.beginTransmission(adrs2);
  Wire.write(exr2);
  Wire.endTransmission();
  exp3 = (Bpin4*128) + (Bpin3*64) + (Bpin2*32) + (Bpin1*16) + (Fpin4*8) + (Fpin3*4) + (Fpin2*2) + Fpin1;
  Wire.beginTransmission(adrs3);
  Wire.write(exp3);
  Wire.endTransmission();
}

//funzioni per i servo
void servo_1(int pins1, int s1c, int s1a){ //funzioni per creare i servomotori servo*(pin, angolo da chiuso, angolo da aperto);
  ledcAttach(pins1, 50, 16);
  pinss1 = pins1;
  ss1a = map(s1a,0,180,pwmmin,pwmmax);
  ss1c = map(s1c,0,180,pwmmin,pwmmax);
}
void servo_2(int pins2, int s2c, int s2a){
  ledcAttach(pins2, 50, 16);
  pinss2 = pins2;
  ss2a = map(s2a,0,180,pwmmin,pwmmax);
  ss2c = map(s2c,0,180,pwmmin,pwmmax);
}
void servo_3(int pins3, int s3c, int s3a){
  ledcAttach(pins3, 50, 16);
  pinss3 = pins3;
  ss3a = map(s3a,0,180,pwmmin,pwmmax);
  ss3c = map(s3c,0,180,pwmmin,pwmmax);
}
void servo_4(int pins4, int s4c, int s4a){
  ledcAttach(pins4,50, 16);
  pinss4 = pins4;
  ss4a = map(s4a,0,180,pwmmin,pwmmax);
  ss4c = map(s4c,0,180,pwmmin,pwmmax);
}
void servo_op(){                           //funzione per aprire i servo
  ledcWrite(pinss1,ss1a);
  ledcWrite(pinss2,ss2a);
  ledcWrite(pinss3,ss3a);
  ledcWrite(pinss4,ss4a);
}
void servo_cl(){                           //funzione per chiudere i servo
  ledcWrite(pinss1,ss1c);
  ledcWrite(pinss2,ss2c);
  ledcWrite(pinss3,ss3c);
  ledcWrite(pinss4,ss4c);
}