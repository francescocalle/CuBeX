#ifndef CuBe_X_
#define CuBe_X_
#include <Arduino.h>

//aggiorna le facce
void af_W(int CFW1,int CFW2,int CFW3,int CFW4,int CFW5,int CFW6,int CFW7,int CFW8);  //quì vanno inseriti i colori delle varie facce (no i centri)
void af_Y(int CFY1,int CFY2,int CFY3,int CFY4,int CFY5,int CFY6,int CFY7,int CFY8);
void af_G(int CFG1,int CFG2,int CFG3,int CFG4,int CFG5,int CFG6,int CFG7,int CFG8);
void af_B(int CFB1,int CFB2,int CFB3,int CFB4,int CFB5,int CFB6,int CFB7,int CFB8);
void af_R(int CFR1,int CFR2,int CFR3,int CFR4,int CFR5,int CFR6,int CFR7,int CFR8);
void af_O(int CFO1,int CFO2,int CFO3,int CFO4,int CFO5,int CFO6,int CFO7,int CFO8);

//restituizione valori
int mosse();             //restituisce il numero di mosse
int errori();            //restituisce il valore di errore (0 nessun errore)
int mossa(int nmnm);     //restituisce un numero che sta ad indicare la mossa nella posizione del numero dato in ingresso
int tempo();             //restituisce un numero che sta ad indicare il tempo in millisecondi impiegato per eseguire la risoluzione

//start processo
void start();            //richiamando questa funzione verrà avviata la risoluzione

//void aggiuntivi
void MossaU();
void MossaU1();
void MossaD();
void MossaD1();
void MossaR();
void MossaR1();
void MossaL();
void MossaL1();
void MossaF();
void MossaF1();
void MossaB();
void MossaB1();
void risoluzione();
void semplificazione();
#endif